import React from 'react';
import {AbsoluteFill,Img,staticFile,useCurrentFrame,interpolate} from 'remotion';
export const Scene6CTA:React.FC=()=>{const f=useCurrentFrame();const s=1+0.035*Math.sin(f/8);return <AbsoluteFill style={{background:'#0B0F19',color:'#F9FAFB',fontFamily:'Inter,Arial,sans-serif',alignItems:'center',justifyContent:'center'}}>
 <Img src={staticFile('assets/logo.png')} style={{width:830,height:830,objectFit:'contain'}}/><div style={{marginTop:20,background:'#10B981',color:'#052E24',fontSize:46,fontWeight:900,borderRadius:28,padding:'30px 72px',transform:`scale(${s})`,boxShadow:'0 0 55px #10B98188'}}>CLICK LINK IN BIO 👆</div><div style={{marginTop:38,fontSize:34,fontWeight:900,color:'#FB923C'}}>DAILY NEW JOBS • BINA RATE KAM KIYE</div>
 </AbsoluteFill>};
